<?php

namespace App\Model\Area;

use Illuminate\Database\Eloquent\Model;

class AreaDistrictModel extends Model
{
    protected $table = "area_district";
    protected $primaryKey = "id";
}
