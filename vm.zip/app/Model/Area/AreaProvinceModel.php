<?php

namespace App\Model\Area;

use Illuminate\Database\Eloquent\Model;

class AreaProvinceModel extends Model
{
    protected $table = "area_province";
    protected $primaryKey = "id";
}
