<?php

namespace App\Model\Area;

use Illuminate\Database\Eloquent\Model;

class RegencyCooperateModel extends Model
{
    protected $table="home_regency";
    protected $primaryKey="id_home_regency";
}
