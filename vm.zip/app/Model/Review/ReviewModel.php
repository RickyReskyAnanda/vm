<?php

namespace App\Model\Review;

use Illuminate\Database\Eloquent\Model;

class ReviewModel extends Model
{
    protected $table = "review";
    protected $primaryKey = "id_Reviewreview";
}
