<?php

namespace App\Model\Room;

use Illuminate\Database\Eloquent\Model;

class RoomGalleryModel extends Model
{
    protected $table = "room_gallery";
    protected $primaryKey = "id_room_gallery";
}
