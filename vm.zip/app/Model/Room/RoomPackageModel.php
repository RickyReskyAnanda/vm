<?php

namespace App\Model\Room;

use Illuminate\Database\Eloquent\Model;

class RoomPackageModel extends Model
{
    protected $table = "room_package";
    protected $primaryKey = "id_room_package";
}
