<?php

namespace App\Model\Room;

use Illuminate\Database\Eloquent\Model;

class RoomTypeModel extends Model
{
    protected $table = 'room_type';
    protected $primaryKey = 'id_room_type';
}
