<?php

namespace App\Model\Setting;

use Illuminate\Database\Eloquent\Model;

class SettingModel extends Model
{
    protected $table = "web_setting";
    protected $primaryKey = "id_setting";
}
