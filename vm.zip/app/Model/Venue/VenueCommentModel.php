<?php

namespace App\Model\Venue;

use Illuminate\Database\Eloquent\Model;

class VenueCommentModel extends Model
{
    protected $table = 'venue_comment';
    protected $primaryKey = 'id_venue_comment';
}
