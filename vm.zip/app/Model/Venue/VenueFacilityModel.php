<?php

namespace App\Model\Venue;

use Illuminate\Database\Eloquent\Model;

class VenueFacilityModel extends Model
{
    protected $table = "venue_facility";
    protected $primaryKey = "id_venue_facility";
}
