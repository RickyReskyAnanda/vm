<?php

namespace App\Model\Area;

use Illuminate\Database\Eloquent\Model;

class AreaRegencyModel extends Model
{
    protected $table = "area_regency";
    protected $primaryKey = "id";
}
