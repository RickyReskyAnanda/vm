<?php

namespace App\Model\Home;

use Illuminate\Database\Eloquent\Model;

class HomeVenueRegisterModel extends Model
{
    protected $table = "partner_register";
    protected $primaryKey = "id_register";
}
