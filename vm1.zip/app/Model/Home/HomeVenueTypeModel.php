<?php

namespace App\Model\Home;

use Illuminate\Database\Eloquent\Model;

class HomeVenueTypeModel extends Model
{
    protected $table = "home_venue_type";
    protected $primaryKey = "id_type";
}
