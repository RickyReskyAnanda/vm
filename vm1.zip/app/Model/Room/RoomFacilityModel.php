<?php

namespace App\Model\Room;

use Illuminate\Database\Eloquent\Model;

class RoomFacilityModel extends Model
{
    protected $table= "room_facility";
    protected $primaryKey= "id_room_facility";
}
