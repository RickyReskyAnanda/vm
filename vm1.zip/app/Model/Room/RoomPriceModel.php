<?php

namespace App\Model\Room;

use Illuminate\Database\Eloquent\Model;

class RoomPriceModel extends Model
{
    protected $table = "room_price";
    protected $primaryKey = "id_room_price";
}
