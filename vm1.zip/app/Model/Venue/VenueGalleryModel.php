<?php

namespace App\Model\Venue;

use Illuminate\Database\Eloquent\Model;

class VenueGalleryModel extends Model
{
    protected $table = 'venue_gallery';
    protected $primaryKey = 'id_venue_gallery';
}
