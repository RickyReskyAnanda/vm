<?php

namespace App\Model\Venue;

use Illuminate\Database\Eloquent\Model;

class VenuePackageModel extends Model
{
    protected $table = "venue_package";
    protected $primaryKey = "id_package";
}
