@extends('administrator.index')

@section('content')
<div class="main">
	<!-- MAIN CONTENT -->
	<div class="main-content">
		<div class="container-fluid">
			@if (session('pesan'))
		        <div class="alert alert-success alert-dismissable">
		            <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
		            {{session('pesan')}}
		        </div>
		    @endif
			<div class="panel">
				<div class="panel-heading">
					<h3 class="panel-title">Daftar User</h3>
				</div>
				<div class="panel-body">
					<!-- Button trigger modal -->
					<table class="table">
						<thead>
							<tr>
								<th width="5%">No</th>
								<th>Nama</th>
								<th>Email</th>
								<th>Key</th>
								<th>Aktif</th>
							</tr>
						</thead>
						<tbody>
							<?php $i=1;?>
							@foreach($data as $user)
							<tr>
								<td>{{$i++}}</td>
								<td>{{$user->name}}</td>
								<td>{{$user->email}}</td>
								<td>{{$user->key_pw}}</td>
								<td>
									@if($user->active == '1')
									Aktif
									@elseif($user->active == '2')
									Terhapus
									@elseif($user->active == '3')
									Terblokir
									@elseif($user->active == '0')
									Belum Aktif
									@endif
								</td>
							</tr>
							@endforeach
						</tbody>
					</table>
					<div class="row">
						<div class="col-md-6 col-md-offset-3 text-center">
							 <ul class="pagination">
							  <li class="page-item"><a class="page-link" href="{{$data->url(1)}}">First</a></li>
							  <li class="page-item"><a class="page-link" href="{{$data->previousPageUrl()}}">Previous</a></li>
							  <li class="page-item"><a class="page-link" href="{{$data->nextPageUrl()}}">Next</a></li>
							  <li class="page-item"><a class="page-link" href="{{$data->lastPage()}}">Last</a></li>
							</ul> 
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- END MAIN CONTENT -->
</div>
@endsection