<!DOCTYPE html>
<html lang="en">
<head>
 <meta charset="UTF-8">
 <title>Email</title>
</head>
<body>

Hi <strong>{{ $name }}</strong>,<br>
<p><a href="{{ $activation_link }}">Click here</a> to activate your account.</p>
<p style="color:red;">CeklokasiID</p>
</body>
</html>