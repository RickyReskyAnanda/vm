<script src="{{asset('assets/homepage/vendor/bootstrap/js/bootstrap.bundle.min.js')}}"></script>

<!-- Plugin JavaScript -->
<script src="{{asset('assets/homepage/vendor/jquery-easing/jquery.easing.min.js')}}"></script>
<script src="{{asset('assets/homepage/vendor/scrollreveal/scrollreveal.min.js')}}"></script>
<script src="{{asset('assets/homepage/vendor/magnific-popup/jquery.magnific-popup.min.js')}}"></script>
